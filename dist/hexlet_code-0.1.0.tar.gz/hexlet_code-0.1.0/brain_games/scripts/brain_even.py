from brain_games.engine import engine
from brain_games.games import br_even


def main():
	engine(br_even)


if __name__ == '__main__':
	main()
