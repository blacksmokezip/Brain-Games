from brain_games.engine import engine
from brain_games.games import br_calc


def main():
	engine(br_calc)


if __name__ == '__main__':
	main()
